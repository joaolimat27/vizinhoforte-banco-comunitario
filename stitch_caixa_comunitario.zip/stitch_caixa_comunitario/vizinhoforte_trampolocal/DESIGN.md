---
name: VizinhoForte / TrampoLocal
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#3c4a42'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#6c7a71'
  outline-variant: '#bbcabf'
  surface-tint: '#006c49'
  primary: '#006c49'
  on-primary: '#ffffff'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#4edea3'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#0053db'
  on-tertiary: '#ffffff'
  tertiary-container: '#7f9fff'
  on-tertiary-container: '#00328b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.375rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style
This design system is tailored for a hyper-local community micro-service exchange, connecting independent neighborhood workers (handymen, seamstresses, caretakers, bakers, electricians) with local residents, particularly older adults and everyday citizens.

The aesthetic blends **Modern Practical Minimalism** with **Tactile Accessibility**. It rejects hyper-abstract tech tropes in favor of honest, high-legibility, and instantly reassuring visual language grounded in Brazilian street-level commerce (clear signs, straightforward pricing, and immediate contact via WhatsApp).

### Core Pillars
- **Direct & Frictionless:** Zero unnecessary jargon or multi-step flows. Actions are explicit and immediately understandable.
- **Ultra-Accessible & Tactile:** Generously proportioned touch targets, legible hierarchy, and distinct visual affordances that empower non-tech-savvy users and seniors.
- **Dignified & Trustworthy:** Balances the warmth of local solidarity with the institutional safety and rigor of a community credit union or cooperative bank.

## Colors
The palette prioritizes clarity, extreme contrast ratios (conforming to WCAG AAA standards for critical texts), and the psychological assurance of safety and livelihood.

- **Primary (`#10B981` — Emerald Green):** The engine of transactional vitality, immediate availability, and WhatsApp action channels. Evokes prosperity, neighborhood solidarity, and quick confirmation.
- **Secondary (`#0F172A` — Deep Slate Blue):** Used for typography, structural chrome, and authority. Replaces pure black to deliver deep contrast without visual harshness.
- **Tertiary (`#2563EB` — Community Blue):** Reserved for institutional receipts, ledger confirmations, verification seals, and secondary utility badges.
- **Neutral Canvas (`#F8FAFC` — Soft Off-White):** A tranquil, glare-free backdrop that allows white service cards (`#FFFFFF`) to stand out effortlessly.
- **Structural Border (`#E2E8F0` — Subtle Slate Border):** Provides tactile bounding boxes so low-vision users can clearly perceive card and button edges under outdoor daylight.
- **Status Signals:**
  - *Available / Livre Hoje:* Soft Emerald background (`#ECFDF5`) with Deep Forest typography (`#065F46`).
  - *Busy / Em Serviço:* Soft Amber background (`#FEF3C7`) with Warm Umber typography (`#92400E`).

## Typography
The system uses **Inter** throughout all tiers to guarantee high legibility on modest mobile screens, high rendering fidelity across Android distributions, and distinct distinction between numerals (essential for micro-service pricing and phone digits).

### Accessibility Rules
- Body text never drops below `16px` for primary user flows, shielding seniors and visually fatigued users from squinting.
- Micro-labels (`label-sm`, `12px`) are restricted exclusively to secondary badges, meta-timestamps, and legal disclaimers, always set in `700` bold to protect stroke weight.
- Generous line heights are strictly maintained to prevent tap confusion and accidental double-taps on dense service listings.

## Layout & Spacing
A **mobile-first single-column fluid grid** anchors the user experience, mirroring typical WhatsApp and delivery ergonomics.

### Form Factors & Adaptation
- **Mobile (< 640px):** Single-column stack. Outer margins are locked to `1rem` (16px) to maximize usable card real estate. Gutters remain `1rem`. Fixed 3-tab navigation anchored to the bottom.
- **Tablet / Phablet (640px - 1024px):** 2-column masonry grid for micro-service listings. Left panel sticky summary or receipt filter.
- **Desktop (> 1024px):** Centered max-width container (`840px` for conversational feed style or `1120px` for full dashboard), maintaining a cozy, neighborhood feel rather than expanding into sparse enterprise space.

### Vertical Rhythm
Touch elements enforce an uninterrupted vertical step pattern using `space-md` (16px) between related card components and `space-xl` (36px) between service category groups.

## Elevation & Depth
Depth in this system avoids heavy, disorienting 3D skeuomorphism in favor of **Crisp Physical Boundaries** and **Air-Cushioned Tonal Elevation**.

- **Level 0 (Floor):** Canvas background `#F8FAFC`. Completely flat.
- **Level 1 (Cards & Service Modules):** Background `#FFFFFF`, bordered with a 1.5px solid stroke of `#E2E8F0`. Layered with an ambient, sun-tinted shadow: `0 2px 4px rgba(15, 23, 42, 0.04)`.
- **Level 2 (Interactive Floating Actions & Modals):** Used for bottom sheets (Confirm Service, WhatsApp Quick Chat) and quick-filter pills. Shadow: `0 8px 24px rgba(15, 23, 42, 0.08)`, border `#CBD5E1`.
- **Level 3 (Fixed Bottom Navigation Bar):** Backed by pure `#FFFFFF` with a clear top border `1.5px solid #E2E8F0` and an upward glow: `0 -4px 12px rgba(15, 23, 42, 0.03)`.

## Shapes
The system deploys a **Rounded (`roundedness: 2`)** geometry. 

- Standard inputs, buttons, and listing cards utilize `0.5rem` (8px) corners to feel robust, friendly, and securely contained.
- Badges, status markers (such as "Livre Hoje"), and bottom-bar indicators step up to `rounded-lg` (1rem / 16px) or fully pill-shaped contours, distinguishing actionable metadata from structural content containers.
- Visual elements avoid aggressive 90-degree corners to ensure a welcoming, community-first atmosphere.

## Components

### 1. Primary Action Buttons (WhatsApp & Solicitação)
- **Dimensions:** Strict minimum height of `52px` (standard) up to `56px` (main CTA) to accommodate larger fingers, tremors, and one-handed thumb use.
- **Visuals:** Background `#10B981`, text `#FFFFFF`, bold `16px` font. Border-radius `0.5rem`.
- **Iconography:** Left-aligned WhatsApp icon or service thunderbolt icon at `24px` size, maintaining `space-sm` separation from the label.
- **States:** Active/Pressed darkens to `#059669`. Focus outlines feature a high-contrast 3px offset `#0F172A`.

### 2. Service Cards
- **Structure:** Pure white `#FFFFFF` surface enclosed by a 1.5px border of `#E2E8F0`. Padding set to `1.25rem`.
- **Header:** Worker avatar (`56px` circle with clear border), followed by name in `#0F172A` (`headline-md`) and neighborhood tag (e.g., "Vila Mariana - 400m").
- **Badge Integration:** Top-right anchored status badge (e.g., "Livre Hoje").
- **Footer:** Prominent pricing display (e.g., "R$ 50/visita" in `#0F172A` bold) alongside the `52px` Emerald Green "Conversar" action.

### 3. Status Tags & Badges
- **"Livre Hoje" (Immediate Availability):** Background `#ECFDF5`, text `#065F46`, left-hand pulse indicator dot (`8px` pure green `#10B981`). Rounded pill format (`rounded-lg`).
- **Verified Neighbor ("Vizinho Verificado"):** Soft blue `#EFF6FF` background with `#1D4ED8` icon and text.

### 4. Input Fields & Search Bars
- **Dimensions:** Height fixed at `52px` with `16px` padding.
- **Styling:** Surface `#FFFFFF`, border `1.5px solid #CBD5E1`. Placeholder text in `#64748B` at `16px` to prevent automatic browser zoom on iOS/Android.
- **Touch Target:** Large magnifying glass icon on left (`24px`) and a clear "Limpar" button on right with a generous 48x48px hit area.

### 5. Checkboxes & Radio Controls
- **Hit Area:** Wrapped in a minimum `48x48px` transparent bounding box. The actual visual box is `24x24px` with a 2px stroke in `#0F172A`.
- **Checked State:** Fills with `#10B981`, checkmark rendered in thick white strokes.

### 6. Fixed 3-Tab Bottom Navigation Bar
- **Tabs:**
  1. *Buscar* (Search/Explore — Icon: Compass / Map Pin)
  2. *Meus Recibos* (My Receipts / Micro-transactions — Icon: Receipt Paper / Shield)
  3. *Meu Perfil* (Profile / My Trampos — Icon: User Circle)
- **Bar Height:** `68px` plus safe-area-inset padding for devices with gesture bars.
- **Active State:** Active icon and text highlight in `#10B981` with an elevated 3px top indicator bar; inactive states rest in neutral `#64748B`.
- **Text Labels:** Always visible underneath the icon (`label-sm`), never hidden behind icon-only layouts.